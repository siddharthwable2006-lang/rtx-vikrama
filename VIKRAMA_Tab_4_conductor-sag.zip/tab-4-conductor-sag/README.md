# VIKRAMA Tab 4 — Conductor Sag

GitHub-ready standalone tab. Upload this folder as-is.

Files: `index.html`, `style.css`, `script.js`.

Demo data is for UI demonstration and is not a certified safety limit.

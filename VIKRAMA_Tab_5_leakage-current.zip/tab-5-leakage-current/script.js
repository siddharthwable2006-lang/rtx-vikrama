// Tab-specific JavaScript is embedded in index.html for this standalone build.
